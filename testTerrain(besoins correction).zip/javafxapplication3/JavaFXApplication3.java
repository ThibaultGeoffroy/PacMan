/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication3;

import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.jmx.MXNodeAlgorithm;
import com.sun.javafx.jmx.MXNodeAlgorithmContext;
import com.sun.javafx.sg.prism.NGNode;
import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class JavaFXApplication3 extends Application {

    public class Case {

        private int value;

        public Case(int valueset) {
            this.value = valueset;
        }

        public void setValue(int valuetoset) {
            this.value = valuetoset;
        }

        public int getValue() {
            return this.value;
        }
    }
    final int LENGTH_X = 13;
    final int LENGTH_Y = 20;
    private Case[][] Gmap = new Case[LENGTH_X][LENGTH_Y];

    @Override
    public void start(Stage primaryStage) throws IOException {
    Pane myPane = (Pane)FXMLLoader.load(getClass().getResource
                ("FXMLDocument.fxml"));  
        initMapArray();

        myPane.getChildren().add(getGrid());
        Scene scene = new Scene(myPane, 800, 600);
        primaryStage.setTitle("Pacman map test");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    private Pane getGrid() {
        GridPane gridPane = new GridPane();
        Pane wall = new Pane();
        wall.setStyle("-fx-background-color: blue");
        for (int i = 0; i < LENGTH_X; i++) {
            for (int x = 0; x < LENGTH_Y; x++) {
                if (Gmap[i][x].getValue() == 1) {
                    gridPane.add(wall, i, x); // Convert Gmap value to nodes
                }
            }
        }

        return gridPane;
    }

    private void initMapArray() {
        for (int i = 0; i < LENGTH_X; i++) {
            for (int x = 0; x < LENGTH_Y; x++) {
                Gmap[i][x] = new Case((int) (Math.random()));
            }
        }
    }
}
